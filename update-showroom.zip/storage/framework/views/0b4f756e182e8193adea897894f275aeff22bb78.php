

<?php $__env->startSection('content'); ?>
    <!-- content -->
    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <div class="row">
            <ol class="breadcrumb">
                <li><a href="#">
                        <em class="fa fa-home"></em>
                    </a></li>
                <li class="active">Cars</li>
            </ol>
        </div>
        <!--/.row-->

        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">List Cars</h1>
            </div>
        </div>
        <!--/.row-->

        <?php if($message = Session::get('success')): ?>
            <div class="alert bg-teal" role="alert">
                <em class="fa fa-lg fa-check">&nbsp;</em>
                <?php echo e($message); ?>

            </div>
        <?php endif; ?>
        <div class="panel panel-default">
            
            <div class="panel-body">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped b-t b-b" id="tableok">
                            <button class="btn btn-success btn-sm text-white" >
                                <a class="text-white" href="<?php echo e(route('cetak3_pdf')); ?>">Export All PDF</a>
                            </button>
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Vendor Name</th>
                                    <th>Name Of Car</th>
                                    <th>Type Of Car</th>
                                    <th>Model</th>
                                    <th>Status</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no); ?></td>
                                        <td><?php echo e($car->vendor->name_vendor); ?></td>
                                        <td><?php echo e($car->name_car); ?></td>
                                        <td><?php echo e($car->type_car); ?></td>
                                        <td><?php echo e($car->model); ?></td>
                                        <td>
                                            <?php if($car->status_id == 1): ?>
                                                <span class="badge btn-success"><?php echo e($car->status->status); ?></span>
                                            <?php else: ?>
                                                <span class="badge btn-danger"><?php echo e($car->status->status); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e(number_format($car->day_price)); ?></td>
                                        <td>
                                            
                                            <button class="btn btn-primary btn-sm" data-toggle="modal"
                                                data-target="#Detailcar-<?php echo e($car->id); ?>">
                                                Detail
                                            </button>
                                            <button class="btn btn-danger btn-sm">
                                                <a href="<?php echo e(route('cetak2_pdf', $car->id)); ?>">PDF</a>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php $no++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="table-responsive">
                    </div>
                </div>
            </div><!-- /.panel-->
        </div>
        <!--/.main-->

        <!-- The Modal -->
        

        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            

            <div class="modal" id="Detailcar-<?php echo e($car->id); ?>">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">

                        <!-- Modal Header -->
                        <div class="modal-header">
                            <h4 class="modal-title">Detail car</h4>
                        </div>

                        <!-- Modal body -->
                        <div class="modal-body">
                            <div class="container">
                                <div class="row" style="margin-bottom: 20px">
                                    <div class="col-xs-3">
                                        <img src="<?php echo e($car->img_car3); ?>" alt=""
                                            style="height: 150px;width: 100%">
                                    </div>
                                    <div class="col-xs-3">
                                        
                                        <img src="<?php echo e($car->img_car2); ?>" alt=""
                                            style="height: 150px;width: 100%">
                                    </div>
                                    <div class="col-xs-3">
                                        <img src="<?php echo e($car->img_car); ?>" alt="" style="height: 150px;width: 100%">
                                        
                                    </div>
                                </div>
                                <div class="row" style="margin-bottom: 20px">
                                    <div class="col-xs-9">
                                        <img src="<?php echo e($car->img_car); ?>" alt="" style="height: 300px;width: 100%">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-9">
                                        <form action="#" method="post" class="form">
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item">
                                                    <div class="clearfix">
                                                        <span class="pull-left">Type</span>

                                                        <strong
                                                            class="pull-right"><?php echo e(strtoupper($car->type_car)); ?></strong>
                                                    </div>
                                                </li>

                                                <li class="list-group-item">
                                                    <div class="clearfix">
                                                        <span class="pull-left">Vendor</span>

                                                        <strong
                                                            class="pull-right"><?php echo e(strtoupper($car->vendor->name_vendor)); ?></strong>
                                                    </div>
                                                </li>

                                                <li class="list-group-item">
                                                    <div class="clearfix">
                                                        <span class="pull-left"> Model</span>

                                                        <strong class="pull-right"><?php echo e(strtoupper($car->model)); ?></strong>
                                                    </div>
                                                </li>

                                                <li class="list-group-item">
                                                    <div class="clearfix">
                                                        <span class="pull-left">First registration</span>

                                                        <strong
                                                            class="pull-right"><?php echo e(strtoupper($car->fisrt_registartion)); ?></strong>
                                                    </div>
                                                </li>

                                                <li class="list-group-item">
                                                    <div class="clearfix">
                                                        <span class="pull-left">Mileage</span>

                                                        <strong
                                                            class="pull-right"><?php echo e(strtoupper($car->millage)); ?></strong>
                                                    </div>
                                                </li>

                                                <li class="list-group-item">
                                                    <div class="clearfix">
                                                        <span class="pull-left">Fuel</span>

                                                        <strong class="pull-right"><?php echo e(strtoupper($car->fuel)); ?></strong>
                                                    </div>
                                                </li>

                                                <li class="list-group-item">
                                                    <div class="clearfix">
                                                        <span class="pull-left">Engine size</span>

                                                        <strong
                                                            class="pull-right"><?php echo e(strtoupper($car->engine_size)); ?></strong>
                                                    </div>
                                                </li>

                                                <li class="list-group-item">
                                                    <div class="clearfix">
                                                        <span class="pull-left">Power</span>

                                                        <strong class="pull-right"><?php echo e(strtoupper($car->power)); ?></strong>
                                                    </div>
                                                </li>

                                                <li class="list-group-item">
                                                    <div class="clearfix">
                                                        <span class="pull-left">Number of seats</span>

                                                        <strong class="pull-right"><?php echo e(strtoupper($car->seats)); ?></strong>
                                                    </div>
                                                </li>

                                                <li class="list-group-item">
                                                    <div class="clearfix">
                                                        <span class="pull-left">Doors</span>

                                                        <strong class="pull-right"><?php echo e(strtoupper($car->doors)); ?></strong>
                                                    </div>
                                                </li>

                                                <li class="list-group-item">
                                                    <div class="clearfix">
                                                        <span class="pull-left">Color</span>

                                                        <strong class="pull-right"><?php echo e(strtoupper($car->color)); ?></strong>
                                                    </div>
                                                </li>
                                                <li class="list-group-item">
                                                    <div class="clearfix">
                                                        <span class="pull-left">WhatsApp Number</span>

                                                        <strong class="pull-right"><?php echo e(strtoupper($car->whatsapp->nama_cabang)); ?> : <?php echo e(strtoupper($car->whatsapp->wa)); ?></strong>
                                                    </div>
                                                </li>
                                            </ul>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Modal footer -->
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal" id="Deletecar-<?php echo e($car->id); ?>">
                <div class="modal-dialog">
                    <div class="modal-content">

                        <!-- Modal Header -->
                        <div class="modal-header">
                            <h4 class="modal-title">Delete car</h4>

                        </div>

                        <!-- Modal body -->
                        <div class="modal-body">
                            <h5>Are you sure you want to delete data, if the data is deleted it will also delete data
                                related to this data! this action cannot be canceled</h5>
                        </div>

                        <!-- Modal footer -->
                        <div class="modal-footer">
                            <a href="<?php echo e(url('car_delete/' . $car->id)); ?>" class="btn btn-info">Yes</a>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\update-showroom\resources\views/marketing/marketing.blade.php ENDPATH**/ ?>