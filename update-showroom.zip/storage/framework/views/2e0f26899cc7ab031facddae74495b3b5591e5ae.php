<?php echo $__env->make('web.headerdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-heading2 about-heading header-text">
  <h2>Automatic Slideshow</h2>
  <p>Change image every 2 seconds:</p>
  
  <div class="slideshow-container">
  
  <div class="mySlides fade">
    <img src="web/assets/images/mobil3.jpg" style="width: 1349px;height: 455px;">
    <div class="hero">
      <hgroup>
          <h1>KTT8 CARS</h1>        
      </hgroup>
    </div>
  </div>
  
  <div class="mySlides fade">
    <img src="web/assets/images/mobil2.jpg" style="width: 1349px;height: 455px;">
    <div class="hero">
      <hgroup>
          <h1>KTT8 CARS</h1>        
      </hgroup>
    </div>
  </div>
  
  <div class="mySlides fade">
    <img src="web/assets/images/mobil4.jpg" style="width: 1349px;height: 455px;">
    <div class="hero">
      <hgroup>
          <h1>KTT8 CARS</h1>        
      </hgroup>
    </div>
  </div>
  
  </div>
  <br>
  
  <div style="text-align:center">
    <span class="dot"></span> 
    <span class="dot"></span> 
    <span class="dot"></span> 
  </div>
</div>


<!-- Page Content -->
<br><br><br><br>
<div class="">
    <div class="container ">
        <div class="col-md-12">
            <div class="row">
                <?php $modelT = new App\Models\User(); ?>
                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $data = $modelT->cek_booked($car->id); ?>
                    <?php if($car->status_id == 1): ?>
                        <div class="card round">
                            <img class="zoom_01 round" style="width: 520px;height: 360px;" src="<?php echo e($car->img_car); ?>"
                                data-zoom-image="<?php echo e($car->img_car); ?>" />
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 pull-left">
                                        <b>Nama Mobil:</b><br>
                                        <b>Type Mobil:</b><br>
                                        <b>Vendor Mobil:</b>
                                    </div>
                                    <div class="col-md-6 pull-right">
                                        <b><?php echo e($car->name_car); ?></b><br>
                                        <b><?php echo e($car->type_car); ?></b><br>
                                        <b><?php echo e($car->vendor->name_vendor); ?></b>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="row">
                                    <div class="pull-left col-md-6">
                                        <b>RP. <?php echo e($car->day_price); ?></b>
                                    </div>
                                </div>
                            </div>
                        </div>
            </div>
        <?php else: ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</div>
</div>
</div>



<?php $__env->startPush('dashboardfooter'); ?>
<script>
  let slideIndex = 0;
  showSlides();
  
  function showSlides() {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    let dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 3000); // Change image every 2 seconds
  }
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Tugas Kuliah\JOKI AN\showroo-new-face\update-showroom\resources\views/web/dashboard.blade.php ENDPATH**/ ?>