

<?php $__env->startSection('title',$viewproduct["product_meta_title"]); ?>
<?php $__env->startSection('description',$viewproduct["product_meta_description"]); ?>
<?php $__env->startSection('keywords',$viewproduct["product_meta_keywords"]); ?>

<?php $__env->startSection('content'); ?>
    <!-- Banner Here -->
    <div class="banner header-text">
        <div class="owl-banner owl-carousel">            
            <?php $__currentLoopData = $bannerhome; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="banner-item" style="background-image: url(<?php echo e(asset($bh->image)); ?>);">
                    <div class="text-content">
                        <h4>Find your car today!</h4>
                        <h2>Kt 88 Cars For U !</h2>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    </div>
    </div>



    

    <div class="container-fluid">


        <div class="row">
            <?php $modelT = new App\Models\User(); ?>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $data = $modelT->cek_booked($car->id); ?>
                <?php if($car->status_id == 1): ?>
                    <div class="col-md my-2">
                        <div class="card">
                            <img class="zoom_01" src="<?php echo e($car->img_car); ?>" style="height: 100%; width: 100%"
                                data-zoom-image="<?php echo e($car->img_car); ?>" />
                            <div class="card-body">
                                <div class="pull-left">
                                    <p>Nama : </p> <b><?php echo e($car->name_car); ?></b>
                                    <p>Type Mobil:</p> <b><?php echo e($car->type_car); ?></b>
                                    <p>Vendor Mobil:</p> <b><?php echo e($car->vendor->name_vendor); ?></b>
                                </div>
                            </div>

                            <div class="card-footer">
                                <div class="row">
                                    <div class="pull-left col-md-6">
                                        <?php
                                            $hasil_rupiah = number_format($car->day_price, 2, ',', '.');
                                        ?>
                                        Rp.<?php echo e($hasil_rupiah); ?>

                                    </div>
                                    <div class="pull-right col-md-6">
                                        <?php if($data): ?>
                                            <?php if($data->status_transaction == 'process'): ?>
                                                <p align="right"><a href="#" class="btn btn-warning btn-sm"
                                                        data-toggle="modal" data-target="#Booked">Booked</a></p>
                                            <?php elseif($data->status_transaction == 'agree'): ?>
                                                <p align="right"><a href="#" class="btn btn-danger btn-sm"
                                                        data-toggle="modal" data-target="#Sold">Sold</a></p>
                                            <?php else: ?>
                                                <p align="right"><a href="<?php echo e(url('car_detail/' . $car->id)); ?>"
                                                        class="btn btn-info btn-sm">Detail</a></p>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <p align="right"><a href="<?php echo e(url('car_detail/' . $car->id)); ?>"
                                                    class="btn btn-info btn-sm">Detail</a></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
            
            
            

        </div>

    </div>
    </div>
    <div class="modal fade" id="Booked" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">This car have been booked</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="contact-form">
                        <p>This car have been booked , and wil bee ready again if the booked before not pay the invoice !
                        </p>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="Sold" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">This car have been sold</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="contact-form">
                        <p>This car have been sold</p>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.waras', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\update-showroom\resources\views/web/index.blade.php ENDPATH**/ ?>