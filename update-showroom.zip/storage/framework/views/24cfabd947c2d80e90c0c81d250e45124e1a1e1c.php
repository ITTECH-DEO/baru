<?php $__env->startSection("content"); ?>



    
    <br><br><br><br>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-heading">
                    <h2 style="font-weight: bold"><span style="color: orange">Mobil</span> Rekomendasi</h2>
                    
                </div>
            </div>

            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 ">
                    <div class="product-item p-2 shadow rounded">
                        <a href="<?php echo e(route('car.detail', ['id'=>$car["id"]])); ?>"><img class="rounded-lg" src="<?php echo e(url($car->img_car)); ?>" alt="NGeng Ngeng1"></a>
                        <div class="down-content">
                            <a href="<?php echo e(route('car.detail', ['id'=>$car["id"]])); ?>"><h4><?php echo e($car->name_car); ?></h4></a>
                            <?php
                                $hasil_rupiah = "Rp " . number_format($car->day_price,2,',','.');
                            ?>
                            <h6> <?php echo e($hasil_rupiah); ?></h6>

                            <p><?php echo e($car->power); ?> &nbsp;/&nbsp; <?php echo e($car->fuel); ?> &nbsp;/&nbsp; <?php echo e($car->tahun); ?> &nbsp;</p>

                            <small>
                                <strong title="Author"><i class="fa fa-dashboard"></i> <?php echo e($car->millage); ?></strong> &nbsp;&nbsp;&nbsp;&nbsp;
                                <strong title="Author"><i class="fa fa-cube"></i> <?php echo e($car->engine_size); ?></strong>&nbsp;&nbsp;&nbsp;&nbsp;
                                <strong title="Views"><i class="fa fa-cog"></i> <?php echo e($car->type_car); ?></strong>
                            </small>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.waras', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gilangnirwana/Documents/update-showroom/resources/views/web/allcars.blade.php ENDPATH**/ ?>