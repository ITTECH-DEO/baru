<?php $__env->startSection("content"); ?>
<div class="banner header-text">
  <div class="owl-banner owl-carousel">
      <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="banner-item" style="background-image: url(<?php echo e(asset($b->image)); ?>);">
              <div class="text-content">
                  <h4>Find your car today!</h4>
                  <h2>Kt 88 Cars For U !</h2>
              </div>
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
</div>
</div>

    <!-- Banner Ends Here -->

    
    <div class="latest-products">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2 style="font-weight: bold"><span style="color: orange">Rekomendasi</span> Mobil</h2>
              <a href="/all-cars">view more <i class="fa fa-angle-right"></i></a>
            </div>
          </div>


          <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="col-lg-4 col-md-6 ">
            <div class="product-item p-2 shadow rounded">
              <a href="<?php echo e(route('car.detail', ['id'=>$car["id"]])); ?>"><img class="rounded-lg" src="<?php echo e(url($car->img_car)); ?>" alt="NGeng Ngeng1"></a>
              <div class="down-content">
                <a href="<?php echo e(route('car.detail', ['id'=>$car["id"]])); ?>"><h4><?php echo e($car->name_car); ?></h4></a>
                <?php
                    $hasil_rupiah = "Rp " . number_format($car->day_price,2,',','.');
                ?>
                <h6> <?php echo e($hasil_rupiah); ?></h6>
                <p><?php echo e($car->power); ?> &nbsp;/&nbsp; <?php echo e($car->fuel); ?> &nbsp;/&nbsp; <?php echo e($car->tahun); ?> &nbsp;</p>
                <small>
                  <strong title="Author"><i class="fa fa-dashboard"></i> <?php echo e($car->millage); ?></strong> &nbsp;&nbsp;&nbsp;&nbsp;
                  <strong title="Author"><i class="fa fa-cube"></i> <?php echo e($car->engine_size); ?></strong>&nbsp;&nbsp;&nbsp;&nbsp;
                  <strong title="Views"><i class="fa fa-cog"></i> <?php echo e($car->type_car); ?></strong>
                </small>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
    

       
       <div class="latest-products">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="section-heading">
                <h2 style="font-weight: bold"><span style="color: orange">Mobil</span> Matic</h2>
                <a href="/mobil-matic">view more <i class="fa fa-angle-right"></i></a>
              </div>
            </div>
            <?php $__currentLoopData = $matic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 ">
              <div class="product-item p-2 shadow rounded">
                <a href="<?php echo e(route('car.detail', ['id'=>$car["id"]])); ?>"><img class="rounded-lg" src="<?php echo e(url($car->img_car)); ?>" alt="NGeng Ngeng1"></a>
                <div class="down-content">
                  <a href="<?php echo e(route('car.detail', ['id'=>$car["id"]])); ?>"><h4><?php echo e($car->name_car); ?></h4></a>
                  <?php
                      $hasil_rupiah = "Rp " . number_format($car->day_price,2,',','.');
                  ?>
                  <h6> <?php echo e($hasil_rupiah); ?></h6>

                  <p><?php echo e($car->power); ?> &nbsp;/&nbsp; <?php echo e($car->fuel); ?> &nbsp;/&nbsp; <?php echo e($car->tahun); ?> &nbsp;</p>

                  <small>
                    <strong title="Author"><i class="fa fa-dashboard"></i> <?php echo e($car->millage); ?></strong> &nbsp;&nbsp;&nbsp;&nbsp;
                    <strong title="Author"><i class="fa fa-cube"></i> <?php echo e($car->engine_size); ?></strong>&nbsp;&nbsp;&nbsp;&nbsp;
                    <strong title="Views"><i class="fa fa-cog"></i> <?php echo e($car->type_car); ?></strong>
                  </small>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>

      

         
    <div class="latest-products">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2 style="font-weight: bold"><span style="color: orange">Mobil</span> Manual</h2>
              <a href="/mobil-manual">view more <i class="fa fa-angle-right"></i></a>
            </div>
          </div>


          <?php $__currentLoopData = $manual; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="col-lg-4 col-md-6 ">
            <div class="product-item p-2 shadow rounded">
              <a href="<?php echo e(route('car.detail', ['id'=>$car["id"]])); ?>"><img class="rounded-lg" src="<?php echo e(url($car->img_car)); ?>" alt="NGeng Ngeng1"></a>
              <div class="down-content">
                <a href="<?php echo e(route('car.detail', ['id'=>$car["id"]])); ?>"><h4><?php echo e($car->name_car); ?></h4></a>

                <?php
                    $hasil_rupiah = "Rp " . number_format($car->day_price,2,',','.');
                ?>
                <h6> <?php echo e($hasil_rupiah); ?></h6>

                <p><?php echo e($car->power); ?> &nbsp;/&nbsp; <?php echo e($car->fuel); ?> &nbsp;/&nbsp; <?php echo e($car->tahun); ?> &nbsp;</p>

                <small>
                  <strong title="Author"><i class="fa fa-dashboard"></i> <?php echo e($car->millage); ?></strong> &nbsp;&nbsp;&nbsp;&nbsp;
                  <strong title="Author"><i class="fa fa-cube"></i> <?php echo e($car->engine_size); ?></strong>&nbsp;&nbsp;&nbsp;&nbsp;
                  <strong title="Views"><i class="fa fa-cog"></i> <?php echo e($car->type_car); ?></strong>
                </small>
              </div>
            </div>
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>

    








<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.waras', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gilangnirwana/Documents/update-showroom/resources/views/web/dashboard.blade.php ENDPATH**/ ?>