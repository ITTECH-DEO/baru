<?php echo $__env->make('web.headerdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img style="height: 90vh" class="d-block w-100" src="web/assets/images/mobil3.jpg" alt="First slide">
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" style="height: 90vh" src="web/assets/images/mobil2.jpg" alt="Second slide">
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" style="height: 90vh" src="web/assets/images/mobil4.jpg" alt="Third slide">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>
<!-- Page Content -->
<div class="container-fluid m-5">
<h2 style="padding: 20px 20px 30px; margin-top: 2px; text-align: center; position: 
relative;"><span style="color:#FFA500!important">Rekomendasi</span> <span 
style="color:#000000!important">Mobil</span></h2>
    <br/>
    <div class="owl-carousel owl-theme">
        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($car->status_id == 1): ?>
                <div class="card item" style="max-width: 200px;">
                    <img src="<?php echo e($car->img_car); ?>" style="height: 100%; width: 100%" />
                    <div class="card-body">

                        <div class="pull-left">
                            <p>Nama : </p> <b><?php echo e($car->name_car); ?></b>
                            <p>Type Mobil:</p> <b><?php echo e($car->type_car); ?></b>
                            <p>Vendor Mobil:</p> <b><?php echo e($car->vendor->name_vendor); ?></b>
                        </div>
                    </div>
                </div>
            <?php else: ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>

<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    let owl = $('.owl-carousel');
    owl.owlCarousel({
        margin: 25,
        responsiveClass: true,
        autoWidth: true,

    })
    owl.on('mousewheel', '.owl-stage', function(e) {
        if (e.deltaY > 0) {
            owl.trigger('next.owl');
        } else {
            owl.trigger('prev.owl');
        }
        e.preventDefault();
    });
</script>
<?php /**PATH C:\xampp\htdocs\update-showroom\resources\views/web/dashboard.blade.php ENDPATH**/ ?>