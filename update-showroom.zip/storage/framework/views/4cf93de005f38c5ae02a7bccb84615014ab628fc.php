<?php echo $__env->make('web.headerdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>













































            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img style="height: 90vh" class="d-block w-100" src="web/assets/images/mobil3.jpg" alt="First slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" style="height: 90vh" src="web/assets/images/mobil2.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" style="height: 90vh" src="web/assets/images/mobil4.jpg" alt="Third slide">
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>







<!-- Page Content -->
<div class="container-fluid">


    <div class="row">

        <?php $modelT = new App\Models\User(); ?>
        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $data = $modelT->cek_booked($car->id); ?>
            <?php if($car->status_id == 1): ?>
                <div class="col-md my-2">
                    <div class="card ">
                        <img class="zoom_01" src="<?php echo e($car->img_car); ?>" style="height: 100%; width: 100%" data-zoom-image="<?php echo e($car->img_car); ?>" />
                        <div class="card-body">

                            <div class="pull-left">
                                <p>Nama : </p> <b><?php echo e($car->name_car); ?></b>
                                <p>Type Mobil:</p> <b><?php echo e($car->type_car); ?></b>
                                <p>Vendor Mobil:</p> <b><?php echo e($car->vendor->name_vendor); ?></b>
                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="row">
                                <div class="pull-left col-md-6">
                                    <?php
                                        $hasil_rupiah = number_format($car->day_price,2,',','.');
                                    ?>
                                    Rp.<?php echo e($hasil_rupiah); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
        
        
        

    </div>

</div>
</div>



<?php $__env->startPush('dashboardfooter'); ?>
<script>
  let slideIndex = 0;
  showSlides();

  function showSlides() {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    let dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}
    for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 3000); // Change image every 2 seconds
  }
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\update-showroom\resources\views/web/dashboard.blade.php ENDPATH**/ ?>