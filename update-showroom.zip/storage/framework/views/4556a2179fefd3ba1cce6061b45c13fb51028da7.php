<?php echo $__env->make('web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Page Content -->
<div class="page-heading about-heading header-text mb-3" style="background-image: url(<?php echo url('web/assets/images/heading-6-1920x500.jpg'); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="text-content">
                    <h4>KTT8 CARS</h4>
                    <h2>CAR PAGE</h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="">
    <div class="container">
        <div class="col-md-12">
            <div class="row">
                <?php $modelT = new App\Models\User(); ?>
                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $data = $modelT->cek_booked($car->id); ?>
                    <?php if($car->status_id == 1): ?>
                        <div class="col-md-6">
                            <div class="card round">
                                <img class="zoom_01 round" style="width: 520px;height: 360px;" src="<?php echo e($car->img_car); ?>"
                                    data-zoom-image="<?php echo e($car->img_car); ?>" />
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6 pull-left">
                                            <b>Nama Mobil:</b><br>
                                            <b>Type Mobil:</b><br>
                                            <b>Vendor Mobil:</b>
                                        </div>
                                        <div class="col-md-6 pull-right">
                                            <b><?php echo e($car->name_car); ?></b><br>
                                            <b><?php echo e($car->type_car); ?></b><br>
                                            <b><?php echo e($car->vendor->name_vendor); ?></b>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <div class="row">
                                        <div class="pull-left col-md-6">
                                            <b>RP. <?php echo e($car->day_price); ?></b>
                                        </div>
                                        <div class="pull-right col-md-6">
                                            <?php if($data): ?>
                                                <?php if($data->status_transaction == 'process'): ?>
                                                    <p align="right"><a href="#" class="btn btn-warning btn-sm"
                                                            data-toggle="modal" data-target="#Booked">Booked</a></p>
                                                <?php elseif($data->status_transaction == 'agree'): ?>
                                                    <p align="right"><a href="#" class="btn btn-danger btn-sm"
                                                            data-toggle="modal" data-target="#Sold">Sold</a></p>
                                                <?php else: ?>
                                                    <p align="right"><a href="<?php echo e(url('car_detail/' . $car->id)); ?>"
                                                            class="btn btn-info btn-sm">Detail</a></p>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <p align="right"><a href="<?php echo e(url('car_detail/' . $car->id)); ?>"
                                                        class="btn btn-info btn-sm">Detail</a></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
            </div>
        <?php else: ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12">
                <ul class="pages">
                    <?php echo e($cars->links()); ?>

                </ul>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<div class="modal fade" id="Booked" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">This car have been booked</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="contact-form">
                    <p>This car have been booked , and wil bee ready again if the booked before not pay the invoice !
                    </p>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="Sold" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">This car have been sold</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="contact-form">
                    <p>This car have been sold</p>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Tugas Kuliah\JOKI AN\showroo-new-face\update-showroom\resources\views/web/index.blade.php ENDPATH**/ ?>