

<?php $__env->startSection('content'); ?>


<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    <div class="row">
        <ol class="breadcrumb">
            <li><a href="#">
                    <em class="fa fa-home"></em>
                </a></li>
            <li class="active">Leaderboard</li>
        </ol>
    </div>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Leaderboard Penjualan</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-md">

            <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col">QTY</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
                    <tr>
                      <th scope="row"><?php echo e($key=1); ?></th>
                      <td><?php echo e($data->name); ?></td>
                      <td><?php echo e($data->leaderboards_count); ?></td>
                   
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                </tbody>
              </table>


        </div>
    </div>


</div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\update-showroom\resources\views/leaderboard/marketing.blade.php ENDPATH**/ ?>