

<?php $__env->startSection("content"); ?>
<!-- Banner Here -->
<div class="banner header-text">
  <div class="owl-banner owl-carousel">            
      <?php $__currentLoopData = $banneraboutus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="banner-item" style="background-image: url(<?php echo e(asset($bs->image)); ?>);">
              <div class="text-content">
                  <h4>Find your car today!</h4>
                  <h2>Kt 88 Cars For U !</h2>
              </div>
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
</div>
</div>

<div class="products">
  <div class="container">
      <div class="col-lg-12">
          <div class="row ">
              <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-6">
                  <div class="card" style="width: 33rem;">
                      <div class="card-body">
                        <p class="text-justify "><?php echo e($ab->about); ?></p>
                      </div>
                    </div>

                </div><!-- /.col-lg-6 -->
                <div class="col-md-6">
                  <img style="height: 400px; width: 400px float-right" src="<?php echo e($ab->image); ?>" alt="" id="myImg3" class="img-fluid wc-image zoom_01">
                </div><!-- /.col-lg-6 -->
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.waras', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\update-showroom\resources\views/web/aboutUs.blade.php ENDPATH**/ ?>