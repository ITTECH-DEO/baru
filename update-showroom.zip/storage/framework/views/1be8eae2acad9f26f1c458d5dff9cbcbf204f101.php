

<?php $__env->startSection('content'); ?>
    <!-- content -->
    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <div class="row">
            <ol class="breadcrumb">
                <li><a href="#">
                        <em class="fa fa-home"></em>
                    </a></li>
                <li class="active">Banner</li>
            </ol>
        </div>
        <!--/.row-->
        <?php if(Session::has('success')): ?>
        <br>
        <div class="alert alert-success" role="alert">
            Mobil Berhasil Terjual !
          </div>

          <br>
    <?php endif; ?>
        
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Input Penjualan Marketing</h1>
            </div>
        </div>

        <form action="<?php echo e(route('add.penjualan')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="exampleFormControlSelect1">Nama Marketing</label>
                    <select class="form-control" name="user_id" id="exampleFormControlSelect1">
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </select>
                  </div>
            </div>
            <div class="col-md-8">
                <div class="form-group">
                    <label for="exampleFormControlSelect1">List Mobil</label>
                    <select class="form-control" name="car_id" id="exampleFormControlSelect1">
                        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" ><?php echo e($p->name_car); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
            </div>
        </div>
    
            <div class="row">
                <div class="col-md-12">
                    <button class="btn btn-success w-100" type="submit">TERJUAL</button>
                </div>
                
            </div>

        </form>
   
        <!--/.row-->

       
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\update-showroom\resources\views/leaderboard/index.blade.php ENDPATH**/ ?>