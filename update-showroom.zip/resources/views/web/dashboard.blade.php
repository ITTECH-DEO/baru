@include('web.headerdashboard')




{{--  <div class="slideshow-container">--}}

{{--  <div class="mySlides fade">--}}
{{--    <img src="web/assets/images/mobil3.jpg" style="width: 1349px;height: 455px;">--}}
{{--    <div class="hero">--}}
{{--      <hgroup>--}}
{{--          <h1>KTT8 CARS</h1>--}}
{{--      </hgroup>--}}
{{--    </div>--}}
{{--  </div>--}}

{{--  <div class="mySlides fade">--}}
{{--    <img src="web/assets/images/mobil2.jpg" style="width: 1349px;height: 455px;">--}}
{{--    <div class="hero">--}}
{{--      <hgroup>--}}
{{--          <h1>KTT8 CARS</h1>--}}
{{--      </hgroup>--}}
{{--    </div>--}}
{{--  </div>--}}

{{--  <div class="mySlides fade">--}}
{{--    <img src="web/assets/images/mobil4.jpg" style="width: 1349px;height: 455px;">--}}
{{--    <div class="hero">--}}
{{--      <hgroup>--}}
{{--          <h1>KTT8 CARS</h1>--}}
{{--      </hgroup>--}}
{{--    </div>--}}
{{--  </div>--}}

{{--  </div>--}}


{{--  <div style="text-align:center">--}}
{{--    <span class="dot"></span>--}}
{{--    <span class="dot"></span>--}}
{{--    <span class="dot"></span>--}}
{{--  </div>--}}




            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img style="height: 90vh" class="d-block w-100" src="web/assets/images/mobil3.jpg" alt="First slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" style="height: 90vh" src="web/assets/images/mobil2.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" style="height: 90vh" src="web/assets/images/mobil4.jpg" alt="Third slide">
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>







<!-- Page Content -->
<div class="container-fluid">


    <div class="row">

        @php $modelT = new App\Models\User(); @endphp
        @foreach ($cars as $car)
            @php $data = $modelT->cek_booked($car->id); @endphp
            @if ($car->status_id == 1)
                <div class="col-md my-2">
                    <div class="card ">
                        <img class="zoom_01" src="{{ $car->img_car }}" style="height: 100%; width: 100%" data-zoom-image="{{ $car->img_car }}" />
                        <div class="card-body">

                            <div class="pull-left">
                                <p>Nama : </p> <b>{{ $car->name_car }}</b>
                                <p>Type Mobil:</p> <b>{{ $car->type_car }}</b>
                                <p>Vendor Mobil:</p> <b>{{ $car->vendor->name_vendor }}</b>
                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="row">
                                <div class="pull-left col-md-6">
                                    @php
                                        $hasil_rupiah = number_format($car->day_price,2,',','.');
                                    @endphp
                                    Rp.{{ $hasil_rupiah }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @else
            @endif
        @endforeach
        {{--            <div class="col-md">--}}
        {{--                <ul class="pages">--}}
        {{--                    {{ $cars->links() }}--}}
        {{--                </ul>--}}
        {{--            </div>--}}

    </div>

</div>
</div>
{{-- <div class="modal fade" id="Booked" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">This car have been booked</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="contact-form">
                    <p>This car have been booked , and wil bee ready again if the booked before not pay the invoice !
                    </p>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> --}}

{{-- <div class="modal fade" id="Sold" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">This car have been sold</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="contact-form">
             <p>This car have been sold</p>
          <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> --}}
@push('dashboardfooter')
<script>
  let slideIndex = 0;
  showSlides();

  function showSlides() {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    let dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}
    for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 3000); // Change image every 2 seconds
  }
  </script>
@endpush
@include('web.footer')
